﻿using CGUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CGAlgorithms.Algorithms.ConvexHull
{
    public class ExtremeSegments : Algorithm
    {

        public static void RemoveDuplicatePoints(ref List<Point> inputPoints)
        {
            for (int pointA = 0; pointA < inputPoints.Count; pointA++)
            {
                for (int pointB = pointA + 1; pointB < inputPoints.Count; pointB++)
                {
                    if (inputPoints[pointA].Equals(inputPoints[pointB]))
                    {
                        inputPoints.RemoveAt(pointB);
                        pointB--;
                        break;
                    }
                }
            }
        }

        private static void ProcessPoints(List<Point> points, ref HashSet<Point> output, ref List<Point> toBeRemovedPoints,
            ref int leftAndRightRotation, ref int colinear)
        {
            for (int pointA = 0; pointA < points.Count; pointA++)
            {
                for (int pointB = pointA + 1; pointB < points.Count; pointB++)
                {
                    Line ab = new Line(points[pointA], points[pointB]);

                    for (int comparedPoint = 0; comparedPoint < points.Count; comparedPoint++)
                    {
                        if (points[comparedPoint] != points[pointA] && points[comparedPoint] != points[pointB])
                        {
                            CheckPointOnSegment(points, ab, comparedPoint, ref leftAndRightRotation, ref colinear, toBeRemovedPoints);
                        }
                    }

                    CheckAndAddToOutput(points, ab, pointA, pointB, leftAndRightRotation, colinear, ref output);
                    ResetCounters(ref leftAndRightRotation, ref colinear);
                }
            }
        }

        private static void CheckPointOnSegment(List<Point> points, Line ab, int comparedPoint, ref int leftAndRightRotation,
            ref int colinear, List<Point> toBeRemovedPoints)
        {
            switch (HelperMethods.CheckTurn(ab, points[comparedPoint]))
            {
                case Enums.TurnType.Left:
                    leftAndRightRotation--;
                    break;
                case Enums.TurnType.Right:
                    leftAndRightRotation++;
                    break;
                default:
                    colinear++;

                    if (HelperMethods.PointOnSegment(points[comparedPoint], ab.Start, ab.End))
                    {
                        toBeRemovedPoints.Add(points[comparedPoint]);
                    }

                    break;
            }
        }

        private static void CheckAndAddToOutput(List<Point> points, Line ab, int pointA, int pointB,
            int leftAndRightRotation, int colinear, ref HashSet<Point> output)
        {
            if (Math.Abs(leftAndRightRotation) == (points.Count - 2 - colinear))
            {
                output.Add(points[pointA]);
                output.Add(points[pointB]);
            }
        }

        private static void ResetCounters(ref int leftAndRightRotation, ref int colinear)
        {
            leftAndRightRotation = 0;
            colinear = 0;
        }

        public override void Run(List<Point> points, List<Line> lines, List<Polygon> polygons, ref List<Point> outPoints,
            ref List<Line> outLines, ref List<Polygon> outPolygons)
        {
            if (points.Count == 1)
            {
                outPoints = points;
                return;
            }

            RemoveDuplicatePoints(ref points);
            HashSet<Point> output = new HashSet<Point>();
            List<Point> toBeRemovedPoints = new List<Point>();
            int leftAndRightRotation = 0, colinear = 0;

            ProcessPoints(points, ref output, ref toBeRemovedPoints, ref leftAndRightRotation, ref colinear);
            RemovePointsFromOutput(output, toBeRemovedPoints);

            outPoints = output.ToList();
        }

        private static void RemovePointsFromOutput(HashSet<Point> output, List<Point> toBeRemovedPoints)
        {
            foreach (var pointToRemove in toBeRemovedPoints)
            {
                output.Remove(pointToRemove);
            }
        }

        public override string ToString()
        {
            return "Convex Hull - Extreme Segments";
        }
    }
}
