﻿using CGUtilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CGAlgorithms.Algorithms.ConvexHull
{
    public class GrahamScan : Algorithm
    {
        public static List<Point> BuildStack(List<Point> points, Point S) 
        {
            Stack<Point> convexHull = new Stack<Point>();
            convexHull.Push(S);
            convexHull.Push(points[1]);
            for (int i = 2; i < points.Count; i++)
            {
                while (convexHull.Count > 1 &&
                    HelperMethods.CheckTurn(new Line(Top(convexHull),convexHull.Peek()), points[i]) != Enums.TurnType.Left)
                {
                    convexHull.Pop();
                }
                convexHull.Push(points[i]);
            }

            return convexHull.ToList();
        }
        public static Point FindStartPoint(List<Point> points)
        {
            Point SP = points[0];

            for (int i = 0; i < points.Count; i++)
            {
                if (points[i].Y < SP.Y || (points[i].X < SP.X && points[i].Y == SP.Y))
                {
                    SP = points[i];
                }
            }

            return SP;
        }

        public static List<Point> Convex(List<Point> points, Point S) 
        {
            List<Point> convex = new List<Point>();
           convex= points.OrderBy(p => Math.Atan2(p.Y - S.Y, p.X - S.X))
                        .ThenBy(p => HelperMethods.Distance(S, p)).ToList();
            return convex;
        }
        static Point Top(Stack<Point> convexHull)
        {
            
            Point Top = convexHull.Pop();
            Point Topp = convexHull.Peek();
            convexHull.Push(Top);
            return Topp;
        }

        public static List<Point> Basecase(List<Point> points) 
        {
            if (points.Count <= 3)
            {
                return points;
            }

            List<Point> convexHullPoint = new List<Point>();
            Point newStartPoint = FindStartPoint(points);
            convexHullPoint = Convex(points, newStartPoint);
            List<Point> outPoints = new List<Point>();
            outPoints = BuildStack(convexHullPoint, newStartPoint);
            return outPoints;
        }
        public static List<Point> Test(List<Point> points)
        {
           
           return Basecase(points).ToList();
        }

        public override void Run(List<Point> points, List<Line> lines, List<Polygon> polygons, ref List<Point> outPoints, ref List<Line> outLines, ref List<Polygon> outPolygons)
        {
            outPoints = Test(points);
        }

        public override string ToString()
        {
            return "Convex Hull - Graham Scan";
        }
    }
}
