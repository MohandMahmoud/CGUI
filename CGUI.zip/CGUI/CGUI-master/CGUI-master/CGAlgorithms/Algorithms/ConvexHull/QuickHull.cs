﻿using CGUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CGAlgorithms.Algorithms.ConvexHull
{
    public class QuickHull : Algorithm
    {
        public List<Point> QuickHullAlgorithm(List<Point> points, Point minPoint, Point maxPoint, Enums.TurnType turnType)
        {
            Enums.TurnType newTurnType = (turnType == Enums.TurnType.Right) ? Enums.TurnType.Right : Enums.TurnType.Left;
            int index = FindFarthestPointIndex(points, minPoint, maxPoint, newTurnType);
            double maxDistance = (index != -1) ? CalculateDistance(points[index], minPoint, maxPoint) : -1;

            List<Point> result = new List<Point>();

            if (index == -1)
            {
                result.Add(minPoint);
                result.Add(maxPoint);
                return result;
            }

            List<Point> part1 = QuickHullAlgorithm(points, points[index], minPoint, GetOppositeTurnType(newTurnType));
            List<Point> part2 = QuickHullAlgorithm(points, points[index], maxPoint, newTurnType);

            result.AddRange(part1);
            result.AddRange(part2);

            return result;
        }

        private int FindFarthestPointIndex(List<Point> points, Point minPoint, Point maxPoint, Enums.TurnType newTurnType)
        {
            int index = -1;
            double maxDistance = -1;

            for (int i = 0; i < points.Count; i++)
            {
                double distance = CalculateDistance(points[i], minPoint, maxPoint);
                Enums.TurnType pointTurnType = HelperMethods.CheckTurn(new Line(minPoint, maxPoint), points[i]);

                if (pointTurnType == newTurnType && distance > maxDistance)
                {
                    index = i;
                    maxDistance = distance;
                }
            }

            return index;
        }

        private double CalculateDistance(Point point, Point minPoint, Point maxPoint)
        {
            return Math.Abs((point.Y - minPoint.Y) * (maxPoint.X - minPoint.X) - (maxPoint.Y - minPoint.Y) * (point.X - minPoint.X));
        }

        private Enums.TurnType GetOppositeTurnType(Enums.TurnType turnType)
        {
            return (turnType == Enums.TurnType.Right) ? Enums.TurnType.Left : Enums.TurnType.Right;
        }

        public override void Run(List<Point> points, List<Line> lines, List<Polygon> polygons, ref List<Point> outPoints, ref List<Line> outLines, ref List<Polygon> outPolygons)
        {
            Point maxX = new Point(double.MinValue, 0);
            Point minX = new Point(double.MaxValue, 0);

            FindMinMaxPoints(points, ref minX, ref maxX);

            List<Point> rightHull = QuickHullAlgorithm(points, minX, maxX, Enums.TurnType.Right);
            List<Point> leftHull = QuickHullAlgorithm(points, minX, maxX, Enums.TurnType.Left);

            rightHull.AddRange(leftHull);

            AddUniquePointsToOutput(rightHull, ref outPoints);
        }

        private void FindMinMaxPoints(List<Point> points, ref Point minX, ref Point maxX)
        {
            foreach (Point point in points)
            {
                if (point.X < minX.X)
                    minX = point;
                if (point.X > maxX.X)
                    maxX = point;
            }
        }

        private void AddUniquePointsToOutput(List<Point> pointsToAdd, ref List<Point> outPoints)
        {
            foreach (Point point in pointsToAdd)
            {
                if (!outPoints.Contains(point))
                    outPoints.Add(point);
            }
        }
        public override string ToString()
        {
            return "Convex Hull - Quick Hull";
        }
    }
}
