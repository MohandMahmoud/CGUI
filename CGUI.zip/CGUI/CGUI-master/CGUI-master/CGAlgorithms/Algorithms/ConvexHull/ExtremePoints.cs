﻿using CGUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CGAlgorithms.Algorithms.ConvexHull
{
    public class ExtremePoints : Algorithm
    {

        public override void Run(List<Point> points, List<Line> lines, List<Polygon> polygons, ref List<Point> outPoints, ref List<Line> outLines, ref List<Polygon> outPolygons)
        {
            for (int pointA = 0; pointA < points.Count; pointA++)
            {
                for (int pointB = pointA + 1; pointB < points.Count; pointB++)
                {
                    for (int pointC = pointB + 1; pointC < points.Count; pointC++)
                    {
                        RemovePointsInsideTriangle(points, ref pointA, ref pointB, ref pointC);
                    }
                }
            }
            outPoints = points;
        }

        private void RemovePointsInsideTriangle(List<Point> points, ref int a, ref int b, ref int c)
        {
            int pointIdx = 0;
            while (pointIdx < points.Count)
            {
                if (!IsPointInTriangle(points[pointIdx], points[a], points[b], points[c]))
                {
                    pointIdx++;
                }
                else
                {
                    points.RemoveAt(pointIdx);
                    AdjustIndices(ref a, pointIdx);
                    AdjustIndices(ref b, pointIdx);
                    AdjustIndices(ref c, pointIdx);
                }
            }
        }

        private bool IsPointInTriangle(Point point, Point a, Point b, Point c)
        {
            return point != a && point != b && point != c &&
                   HelperMethods.PointInTriangle(point, a, b, c) != Enums.PointInPolygon.Outside;
        }

        private void AdjustIndices(ref int index, int removedIndex)
        {
            if (index > removedIndex)
            {
                index--;
            }
        }

        public override string ToString()
        {
            return "Convex Hull - Extreme Points";
        }
    }
}
