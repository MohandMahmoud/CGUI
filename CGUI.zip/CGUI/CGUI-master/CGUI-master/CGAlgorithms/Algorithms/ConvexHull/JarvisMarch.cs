﻿using CGUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CGAlgorithms.Algorithms.ConvexHull
{
    public class JarvisMarch : Algorithm
    {
        public static List<Point> algorithm(List<Point> points) 
        {
            List<Point> newConvexHullPoints = new List<Point>();
            Point newStartPoint = FindStartPoint(points);

            newConvexHullPoints.Add(newStartPoint);

            Point newCurrentPoint = newStartPoint;

            for (; ; )
            {
                Point newNextPoint = FindNextPoint(newCurrentPoint, points);
                newConvexHullPoints.Add(newNextPoint);
                newCurrentPoint = newNextPoint;
                if (newCurrentPoint == newStartPoint)
                    break;
            }

            return newConvexHullPoints.Distinct().ToList();
        }

        public static Point FindStartPoint(List<Point> points)
        {
       
            Point SP = points[0];

            for (int i = 0; i < points.Count; i++)
            {
                if (points[i].Y < SP.Y || (points[i].X < SP.X && points[i].Y == SP.Y))
                {
                    SP = points[i];
                }
            }

            return SP;
        }

        public static Point FindNextPoint(Point currentPoint, List<Point> points)
        {
            Point NP = points[0];

            for (int i = 0; i < points.Count; i++)
            {
                if (points[i] == currentPoint)
                    continue;

                Enums.TurnType turnType = HelperMethods.CheckTurn(new Line(currentPoint, NP), points[i]);

                if (turnType == Enums.TurnType.Right ||
                    (turnType == Enums.TurnType.Colinear && HelperMethods.Distance(currentPoint, points[i]) > HelperMethods.Distance(currentPoint, NP)))
                {
                    NP = points[i];
                }
            }

            return NP;
        }

        public static List<Point> Basecase(List<Point> points) 
        {
            if (points.Count <= 3)
                return points;

            return algorithm(points);
        }

        public static List<Point> TEST(List<Point> points)
        {
            return Basecase(points).ToList();
        }

        public override void Run(List<Point> points, List<Line> lines, List<Polygon> polygons, ref List<Point> outPoints, ref List<Line> outLines, ref List<Polygon> outPolygons)
        {
            outPoints = TEST(points);
        }
        public override string ToString()
        {
            return "Convex Hull - Jarvis March";
        }
    }
}
