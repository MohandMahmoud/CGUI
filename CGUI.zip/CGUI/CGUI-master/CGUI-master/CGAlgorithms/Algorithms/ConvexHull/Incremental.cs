﻿using CGUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CGAlgorithms.Algorithms.ConvexHull
{
    public class Incremental : Algorithm
    {
        public override void Run(List<Point> points, List<Line> lines, List<Polygon> polygons, ref List<Point> outPoints, ref List<Line> outLines, ref List<Polygon> outPolygons)
        {
            if (points.Count <= 3) { outPoints = points; return; }

            Remove_DPL(points);

            List<int> Right_LIST = new List<int>();
            List<int> Left_LIST = new List<int>();

            Init(Right_LIST, Left_LIST, points.Count);

            points = SortPoints(points);

            Build_Convex(points, Right_LIST, Left_LIST, ref outPoints);
        }


        private List<Point> SortPoints(List<Point> points) => points.OrderBy(x => x.X).ThenBy(x => x.Y).ToList();
        private bool Compare(Point p1, Point p2) => p1.Y >= p2.Y;
        private Enums.TurnType R_Turn(Line l, List<Point> points, List<int> right, int i) => HelperMethods.CheckTurn(l, points[right[right[i]]]);
        private Enums.TurnType L_Turn(Line l, List<Point> points, List<int> left, int i) => HelperMethods.CheckTurn(l, points[left[left[i]]]);




        private void Init(List<int> R, List<int> L, int n)
        {
            for (int i = 0; i < n; i++)
            {
                R.Add(0);
            }
            for (int i = 0; i < n; i++)
            {
                L.Add(0);
            }
            R[0] = 1;
            L[0] = 1;
        }
        private void Remove_DPL(List<Point> Points)
        {
            for (int i = 0; i < Points.Count; i++)
            {
                for (int j = i + 1; j < Points.Count; j++)
                {
                    if (Points[i].X == Points[j].X && Points[i].Y == Points[j].Y)
                    {
                        Points.RemoveAt(j);
                        j = i + 1;
                    }
                }
            }
        }
        private void Build_OUT(List<Point> Points, List<int> R, ref List<Point> OUT)
        {
            int Index = 0;
            bool CORR = false;

            while (!CORR)
            {
                OUT.Add(Points[Index]);
                Index = R[Index];

                if (Index == 0)
                    CORR = true;
            }
        }
        private void Adjust_R_L_Lists(List<Point> Points, List<int> R, List<int> L, int i)
        {
            for (; R_Turn(new Line(Points[i], Points[R[i]]), Points, R, i) != Enums.TurnType.Left; R[i] = R[R[i]], L[R[i]] = i) ;
            for (; L_Turn(new Line(Points[i], Points[L[i]]), Points, L, i) != Enums.TurnType.Right; L[i] = L[L[i]], R[L[i]] = i) ;
        }
        private void Update_R_L_Lists(List<int> R, List<int> L, int i, bool BIG)
        {
            R[i] = BIG ? R[i - 1] : i - 1;
            L[i] = BIG ? i - 1 : L[i - 1];

            R[L[i]] = i;
            L[R[i]] = i;
        }
        private void Build_Convex(List<Point> Points, List<int> R, List<int> L, ref List<Point> OUT)
        {
            int i = 2;
            while (i < Points.Count)
            {
                bool BIG = Compare(Points[i], Points[i - 1]);

                Update_R_L_Lists(R, L, i, BIG);

                Adjust_R_L_Lists(Points, R, L, i);

                i++;
            }
            Build_OUT(Points, R, ref OUT);

        }

        public override string ToString()
        {
            return "Convex Hull - Incremental";
        }
    }
}
