﻿using CGUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CGAlgorithms.Algorithms.ConvexHull
{
    public class DivideAndConquer : Algorithm
    {
        public static List<Point> DandM(List<Point> points)
        {
            points = points.OrderBy(i => i.X).ThenBy(i => i.Y).ToList();
            List<Point> Convex1 = convex(points);
            points.Reverse();
            List<Point> Convex2 = convex(points);
            Convex1.RemoveAt(Convex1.Count - 1);
            Convex2.RemoveAt(Convex2.Count - 1);

            return Convex1.Concat(Convex2).ToList();
        }
        public static List<Point> Basecase(List<Point> points) 
        {
            if (points.Count <= 3)
                return points;
            return DandM(points);

        }

        public static List<Point> DandC (List<Point> points)
        {
            return Basecase(points);

           
        }

        private static List<Point> convex(List<Point> points)
        {
            List<Point> Convex = new List<Point>();

            for (int i = 0; i < points.Count; i++)
            {
                do
                {
                    if (Convex.Count >= 2 &&
                        HelperMethods.CheckTurn(new Line(Convex[Convex.Count - 2], Convex[Convex.Count - 1]), points[i]) != Enums.TurnType.Right)
                    {
                        Convex.RemoveAt(Convex.Count - 1);
                    }
                    else
                    {
                        break;
                    }
                } while (Convex.Count >= 2);

                Convex.Add(points[i]);
            }

            return Convex;
        }
        public override void Run(List<Point> points, List<Line> lines, List<Polygon> polygons, ref List<Point> outPoints, ref List<Line> outLines, ref List<Polygon> outPolygons)
        {
            outPoints = DandC(points);
        }

        public override string ToString()
        {
            return "Convex Hull - Divide & Conquer";
        }

    }
}
